# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 16:35:02 2023

@author: Franz
"""

import geopandas as gpd
import rasterio
from rasterio import features
import numpy as np

# Ruta de los archivos en tu computador
dem_path = "H:\\Datos\\DEM.tif"
river_path = "H:\\Datos\\rio.shp"
output_path = "H:\\Datos\\flood_depth_4.tif"

# Leer el DEM
with rasterio.open(dem_path) as src:
    dem_array = src.read(1)
    dem_meta = src.meta

# Leer el río
river_gdf = gpd.read_file(river_path)

# Calcular elevación media del río
river_elevations = []
for geom in river_gdf.geometry:
    mask = features.geometry_mask([geom], transform=dem_meta['transform'], invert=True, out_shape=dem_array.shape)
    river_elevations.extend(dem_array[mask])

mean_river_elevation = np.mean(river_elevations)

# Calcular la profundidad de inundación
max_flood_elevation = mean_river_elevation + 4
flood_depth_array = max_flood_elevation - dem_array

# Establecer valores de profundidad de inundación de 0 a NoData (-9999 en este caso)
nodata_value = -9999
flood_depth_array[flood_depth_array <= 0] = nodata_value

# Actualizar metadatos y guardar el ráster de profundidad de inundación
dem_meta['dtype'] = 'float32'  # Set data type to float
dem_meta['nodata'] = nodata_value  # Set NoData value
with rasterio.open(output_path, 'w', **dem_meta) as dst:
    dst.write(flood_depth_array, 1)

print(f"Ráster de profundidad de inundación guardado en: {output_path}")
