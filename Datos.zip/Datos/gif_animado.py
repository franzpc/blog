# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 16:21:27 2023

@author: Franz
"""

import geopandas as gpd
import rasterio
import numpy as np
import matplotlib.pyplot as plt
import imageio
from rasterio import features

# Ruta de los archivos en tu computador
dem_path = "H:\\Datos\\DEM.tif"
river_path = "H:\\Datos\\rio.shp"

# Leer el DEM y el río
with rasterio.open(dem_path) as src:
    dem_array = src.read(1)
    dem_meta = src.meta

river_gdf = gpd.read_file(river_path)

# Función para generar hillshade
def hillshade(array, azimuth, angle_altitude):
    x, y = np.gradient(array)
    slope = np.pi/2. - np.arctan(np.sqrt(x*x + y*y))
    aspect = np.arctan2(-x, y)
    azimuthrad = azimuth * np.pi / 180.
    altituderad = angle_altitude * np.pi / 180.
    
    shaded = np.sin(altituderad) * np.sin(slope) + np.cos(altituderad) * np.cos(slope) * np.cos(azimuthrad - aspect)
    return 255*(shaded + 1)/2

hillshade_array = hillshade(dem_array, 315, 45)

# Calcular elevación media del río
river_elevations = []
for geom in river_gdf.geometry:
    mask = features.geometry_mask([geom], transform=dem_meta['transform'], invert=True, out_shape=dem_array.shape)
    river_elevations.extend(dem_array[mask])

mean_river_elevation = np.mean(river_elevations)

# Generar frames para la animación
intervals = np.arange(0, 2.2, 0.2)
frames = []

for interval in intervals:
    flood_elevation = mean_river_elevation + interval
    flood_mask = dem_array <= flood_elevation
    
    fig, ax = plt.subplots(figsize=(10, 8))
    ax.imshow(hillshade_array, cmap='gray', extent=[dem_meta['transform'][2], 
                                                   dem_meta['transform'][2] + dem_array.shape[1] * dem_meta['transform'][0],
                                                   dem_meta['transform'][5] + dem_array.shape[0] * dem_meta['transform'][4],
                                                   dem_meta['transform'][5]])
    ax.imshow(flood_mask, cmap='Blues', alpha=0.5, extent=[dem_meta['transform'][2], 
                                                          dem_meta['transform'][2] + dem_array.shape[1] * dem_meta['transform'][0],
                                                          dem_meta['transform'][5] + dem_array.shape[0] * dem_meta['transform'][4],
                                                          dem_meta['transform'][5]])
    river_gdf.plot(ax=ax, color='blue', edgecolor='blue')
    ax.set_title(f"Inundación a {interval} m")
    plt.axis('off')
    
    fig.canvas.draw()
    image = np.array(fig.canvas.renderer._renderer)
    plt.close(fig)
    frames.append(image)

# Guardar GIF
gif_path = "H:\\Datos\\flood_animation.gif"
imageio.mimsave(gif_path, frames, duration=0.5, loop=0)

print(f"Animación guardada en: {gif_path}")
